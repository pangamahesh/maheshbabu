package com.ashokit.serviceimpl;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ashokit.binding.CreatePostForm;
import com.ashokit.entity.CreatePostDetails;
import com.ashokit.entity.UserRegistration;
import com.ashokit.repo.CreatePostDetailsRepo;
import com.ashokit.repo.UserRegistrationRepo;
import com.ashokit.service.PostCommentService;

@Service

public class PostCommentServiceImpl implements PostCommentService {

	@Autowired
	private CreatePostDetailsRepo postRepo;

	@Autowired
	private UserRegistrationRepo userRepo;

	@Autowired
	private HttpSession session;

	@Override
	public String savePost(CreatePostForm form) {

		CreatePostDetails entity = new CreatePostDetails();
		BeanUtils.copyProperties(form, entity);

		Integer userId = (Integer) session.getAttribute("userId");

		Optional<UserRegistration> findById = userRepo.findById(userId);
		UserRegistration userDetails = findById.get();

		entity.setUserRegistration(userDetails);

		postRepo.save(entity);

		return "Post created successfully";
	}

	@Override
	public List<CreatePostDetails> getPosts() {

		Integer userId = (Integer) session.getAttribute("userId");

		// TODO: get the userdetails

		Optional<UserRegistration> findById = userRepo.findById(userId);

		UserRegistration userDetails = findById.get();

		// TODO: get the posts of logged in user

		List<CreatePostDetails> totalPosts = userDetails.getCreatePostDetails();

		return totalPosts;
	}

}
