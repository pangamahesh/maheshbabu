package com.ashokit.binding;

import lombok.Data;

@Data
public class CommentsForm {

	private String name;

	private String email;

	private String comment; 

}
