package com.ashokit.binding;

import javax.persistence.Lob;

import lombok.Data;

@Data
public class CreatePostForm {

	
	private String title;

	private String description;


	private String content;

	
	
}
