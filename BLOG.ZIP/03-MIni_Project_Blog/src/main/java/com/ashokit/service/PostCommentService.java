package com.ashokit.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.ashokit.binding.CreatePostForm;
import com.ashokit.entity.CreatePostDetails;

@Component
	public interface PostCommentService {

	public String savePost (CreatePostForm form);
	
	public  List<CreatePostDetails>  getPosts();

}
