package com.ashokit.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.ashokit.binding.CommentsForm;
import com.ashokit.binding.CreatePostForm;
import com.ashokit.entity.CreatePostDetails;
import com.ashokit.service.PostCommentService;

@Controller
public class DashboardController {

	@Autowired
	private PostCommentService service;
	
	@Autowired
	private HttpSession session;
	
	
	@GetMapping("/logout")
	public String logout() {

		session.invalidate();

		return "index";
	}

	
	
	
	

	@GetMapping("/dashboard")
	public String dashboradPage(Model model) {

		List<CreatePostDetails> posts = service.getPosts();
		

		model.addAttribute("blogs", posts);

		return "dashboard";

	}

	@GetMapping("/post")
	public String createPost(Model model) {

		model.addAttribute("newpost", new CreatePostForm());

		return "postpage";

	}

	@PostMapping("/post")
	public String savePost(@ModelAttribute("newpost") CreatePostForm form, Model model) {

		String content = form.getContent();

		String title = form.getTitle();

		String description = form.getDescription();

		service.savePost(form);

		model.addAttribute("newpost", new CreatePostForm());
		// model.addAttribute("msg", status);

		return "postpage";

	}

	@GetMapping("/comment")
	public String giveComment(Model model) {

		model.addAttribute("comments", new CommentsForm());

		return "commentspage";

	}

}
