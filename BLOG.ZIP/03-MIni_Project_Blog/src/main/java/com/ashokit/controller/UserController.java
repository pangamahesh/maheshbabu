package com.ashokit.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ashokit.binding.LoginForm;
import com.ashokit.binding.RegistrationForm;
import com.ashokit.entity.CreatePostDetails;
import com.ashokit.repo.CreatePostDetailsRepo;
import com.ashokit.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private CreatePostDetailsRepo postRepo;

	@GetMapping("/")
	public String loadIndexPage(Model model) {

		List<CreatePostDetails> findAll = postRepo.findAll();

		model.addAttribute("bloglist", findAll);

		return "index";
	}

	  @GetMapping("/blog")
	public String showBlog(@RequestParam Integer postId, Model model) {
		Optional<CreatePostDetails> findBlog = postRepo.findById(postId);

		System.out.println(postId);
		
		if (findBlog.isPresent()) {
			
			System.out.println(findBlog.get().getDescription());

			
			System.out.println(findBlog.get().getContent());
			
			model.addAttribute("display", findBlog.get());
			return "blogpage";
		}
	
	  return "index";
	  
	  }
	  

	@GetMapping("/register")

	public String loadRegister(Model model) {

		model.addAttribute("signup", new RegistrationForm());

		return "register";

	}

	@PostMapping("/register")
	public String registration(@ModelAttribute("signup") RegistrationForm form, Model model) {

		boolean status = service.userSignup(form);

		if (status) {
			model.addAttribute("succMsg", "Sign up Successfully");
		} else {
			model.addAttribute("errMsg", "erorr occured..");
		}

		model.addAttribute("signup", new RegistrationForm());

		return "register";

	}

	@GetMapping("/login")
	public String loginPage(Model model) {

		model.addAttribute("loginForm", new LoginForm());
		return "login";

	}

	@PostMapping("/login")
	public String login(@ModelAttribute("loginForm") LoginForm form, Model model) {

		boolean status = service.loginVerify(form);

		if (status) {
			// display dashboard
			return "redirect:/dashboard";
		} else {

			model.addAttribute("errMsg", "Invalid credentials");

			return "login";
		}

	}

}